from youtube_transcript_api import YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_huggingface import ChatHuggingFace, HuggingFacePipeline
from dotenv import load_dotenv 
from langchain_core.prompts import PromptTemplate 
from langchain_core.output_parsers import StrOutputParser
from langchain_chroma import Chroma

load_dotenv()  

# --------------extracting youtube transcript for a given video id----------------
video_id = "6xePkn3-LME" # "aDG1T0kJnd4" "PGUdWfB8nLg" "Gfr50f6ZBvo" "-HzgcbRXUK8" 

try:
    transcript_list = YouTubeTranscriptApi.get_transcript(video_id, languages=['en'])
except TranscriptsDisabled:
    print("Subtitles are disabled for this video.")
except NoTranscriptFound:
    print("No transcript found for this video.")
except Exception as e:
    print("Error:", e)

transcript = "".join([entry['text'] for entry in transcript_list])

# --------------splitting transcript into smaller chunks----------------
splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
)

docs = splitter.create_documents([transcript])

print("Total number of documents created :",len(docs))

# --------------creating embeddings_model and vectorDB to make knowledge base----------------

# loading embedding model 
myembeddingsmodel = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={'device': 'cpu'} 
)

# creating vector store 
vector_store = Chroma( 
    embedding_function=myembeddingsmodel,
    persist_directory="my_chroma_db",
    collection_name="my_collection" 
)

# adding documents 
vector_store.add_documents(docs) 

print("Total number of documents added to vector store :",len(docs))

# --------------similarity search in vector store----------------

user_query = "What is Integrated Gradient in XAI ?"  
result = vector_store.similarity_search(
    query= user_query,
    k=5
)

context_text = "\n".join([doc.page_content for doc in result]) 

print("Context retrieved from vector store ! \n")

#--------------Creating LLM and prompt template---------------- 
# loading LLM model
llm = HuggingFacePipeline.from_model_id(
    model_id = "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    task = "text-generation",
    pipeline_kwargs = dict(
        temperature = 0.5,
    )
)

model = ChatHuggingFace(llm = llm) 
# prompt template
final_prompt = PromptTemplate(
    template="Use the below context to answer the question. If the context does not help, say 'I don't know'.\n\nContext: {context}\n\nQuestion: {question}\n\nAnswer:",
    input_variable=['context', 'question']
)

# creating parser
parser = StrOutputParser()

#--------------generating answer using LLM---------------- 

chain = final_prompt | model | parser
result = chain.invoke({'context': context_text, 'question': user_query}) 
print(result)  
